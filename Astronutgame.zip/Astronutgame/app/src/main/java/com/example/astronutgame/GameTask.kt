package com.example.astronutgame

interface  GameTask
{
    fun closeGame(mScore:Int)

}